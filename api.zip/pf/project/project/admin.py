from django.contrib import admin
from .models import en_temp
# Register your models here.
admin.site.register(en_temp)