from django.contrib import admin
from .models import BFW,Compare

admin.site.register(BFW)


# Register your models here.
admin.site.register(Compare)