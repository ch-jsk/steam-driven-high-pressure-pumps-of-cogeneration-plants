from django.http import HttpResponse
from django.shortcuts import render,redirect
from.models import BFW, Compare
from django.views.decorators.csrf import csrf_exempt
from .utils import get_plot

def pqs(request):
    return render(request,"hppump.html")


def kelvin(temp):
    temp = float(temp)
    temp += 273
    return temp


def water_values(M,Tc,T0K):
    M = float(M)
    Tc = float(Tc)
    T0K = float(T0K)
    H = (4.3573*Tc)-18.3633
    S = (0.00027*Tc)+1.44215
    E = (M*H)/1000
    e0 = M*T0K
    EX = M*e0
    li = [round(H,4),round(S,4),round(E,4),round(e0,4),round(EX,4)]
    
    return li



def result(request):
    bfw_list = BFW.objects.latest('created_at')
    return render(request,"result_bfw.html",{'bfw_list':bfw_list})

@csrf_exempt
def abc(request):
    if request.method == "POST":
        if request.POST["T0C"] and request.POST.get("name") and request.POST["M7"] and request.POST["M8"] and request.POST["T9C"] and request.POST["M9"] and request.POST["P9"] and request.POST["T10C"] and request.POST["M10"] and request.POST["P10"]:
            var = float(request.POST["P9"])
            var2 = float(request.POST["P10"])
            b = BFW()
            b.Name=request.POST.get("name")
            b.T0C = float(request.POST["T0C"])
            b.T0K = float(kelvin(b.T0C))
            b.M7 = float(request.POST["M7"])
            b.M8 = float(request.POST["M8"])
            b.M9 = float(request.POST["M9"])
            b.M10 = float(request.POST["M10"])
            if request.POST.get("T7C"):
                tc=float(request.POST.get("T7C"))
                if tc !=0:

                    b.T7C = tc
                    b.T7K = float(kelvin(b.T7C))
                    li = water_values(b.M7, b.T7C, b.T0K)
                    b.H7 = li[0]
                    b.S7 = li[1]
                    b.E7 = li[2]
                    b.e07 = li[3]
                    b.EX7 = li[4]
                else:
                    pass
            if request.POST.get("P7"):
                p7=float(request.POST.get("P7"))
                if p7 !=0:

                    b.P7 = p7
                    b.P7kp = float(b.P7 )* 100
                    b.H7 = round((0.173 * float(b.P7kp)+590.73),4)
                    b.S7 = round((0.000374 * float(b.P7kp)+ 1.7671),4)
                    b.e07 = round((float(b.H7 ) - float(b.T0K) * float(b.S7)),4)
                    b.E7 = round((float(b.M7)* float(b.H7) / 1000),4)

                    b.EX7 = round((float(b.M7) * float(b.e07)/ 1000),4)
                else:
                    pass

            if request.POST.get("T8C"):
                t8c=float(request.POST.get("T8C"))
                if t8c !=0:

                    b.T8C = t8c
                    b.T8K = float(kelvin(b.T8C))
                    li = water_values(b.M8, b.T8C, b.T0K)
                    b.H8 = li[0]
                    b.S8 = li[1]
                    b.E8 = li[2]
                    b.e08 = li[3]
                    b.EX8 = li[4]
                else:
                    pass
            if request.POST.get("P8"):
                p8=float(request.POST.get("P8"))
                if p8 !=0:

                    b.P8 = p8
                    b.P8kp = float(b.P8) * 100
                    b.H8 = round(0.173 * float(b.P8kp) + 590.73,4)
                    b.S8 = round(0.000374 * float(b.P8kp) + 1.7671,4)
                    b.e08 = round(float(b.H8)  - float(b.T0K) * float(b.S8),4)
                    b.E8 = round(float(b.M8) * float(b.H8)/1000,4)

                    b.EX8 = round((float(b.M8 )*float(b.e08)/1000),2)
            b.T9C = float(request.POST["T9C"])
            b.T9K = float(kelvin(b.T9C))
            b.T10C = float(request.POST["T10C"])
            b.T10K = float(kelvin(b.T10C))
            b.P9 = var
            b.P9kp = var * 100
            b.P10 = var2
            b.P10kp = var2 *100
            if var == 48.0:
                b.H9 = round(2.394 * float(b.T9C) + 2242.7,4)
                b.S9 = round(0.003416 * float(b.T9C) + 5.29918,4)
            elif var == 46.0:
                b.H9 = round(2.362 * float(b.T9C) + 2259.1,4)
                b.S9 = round(0.0034092 * float(b.T9C) + 5.3316,4)
            elif var == 99.1:
                b.H9 = round(2.64806 * float(b.T9C) + 2052.177,4)
                b.S9 = round(0.0035439 * float(b.T9C) + 4.833022,4)
            b.E9 = round(float(b.M9) * float(b.H9) / 1000,4)
            b.e09 = round(float(b.H9) - float(b.T0K) * b.S9,4)
            b.EX9 = round(float(b.M9) * float(b.e09) / 1000,4)

            if var2 == 0.09:
                b.H10 = round(36.26714 * float(b.T10C) + 778.6429,4)
                b.S10 = round(0.1074 * float(b.T10C) + 2.8041,4)
            elif var2 == 1.92:
                b.H10 = round(2.007 * float(b.T10C) + 2469.78,4)
                b.S10 = round(0.0040322* float(b.T10C) + 6.73441,4)
            elif var2 == 5.64:
                b.H10 = round(2.12704 * float(b.T10C) + 2427.064,4)
                b.S10 = round(0.0042748 * float(b.T10C) + 6.146712,4)
            elif var2 == 16.5:
                b.H10 = round(2.3235 * float(b.T10C) + 2336.995,4)
                b.S10 = round(0.0042455 * float(b.T10C) + 5.5973,4)
            b.E10 = round(float(b.M10) * float(b.H10) / 1000,4)
            b.e010 = round(float(b.H10) - float(b.T0K) * b.S10,4)
            b.EX10 = round(float(b.M10) * float(b.e010) / 1000,4)

            b.energy_efficiency = round(((float(b.E8)-float(b.E7))/(float(b.E9)-float(b.E10))*100),4)
            b.energy_loss = round((float(b.E9)+float(b.E7))-(float(b.E10)+float(b.E8)),4)
            b.exergy_efficiency = round(abs(((float(b.EX8)-float(b.EX7))/(float(b.EX10)-float(b.EX9)))*100),4)
            b.exergy_destruction = round(((float(b.EX9)+float(b.EX7))-(float(b.EX10)+float(b.EX8))),4)
            b.save()
            if request.POST.get("compare")=="none" or request.POST.get("compare", False):
                context = request.POST.get("compare")
                return render(request, "compare.html", {'context': context})


            else:
                return redirect('/result/')


@csrf_exempt
def compare(request):
    if request.method == "POST":
        if request.POST["T0C"] and request.POST.get("name") and request.POST["M7"] and request.POST["M8"] and \
                request.POST["T9C"] and request.POST["M9"] and request.POST["P9"] and request.POST["T10C"] and \
                request.POST["M10"] and request.POST["P10"]:
            var = float(request.POST["P9"])
            var2 = float(request.POST["P10"])
            b = Compare()
            b.Name = request.POST.get("name")
            b.T0C = float(request.POST["T0C"])
            b.T0K = float(kelvin(b.T0C))
            b.M7 = float(request.POST["M7"])
            b.M8 = float(request.POST["M8"])
            b.M9 = float(request.POST["M9"])
            b.M10 = float(request.POST["M10"])
            if request.POST.get("T7C"):
                tc = float(request.POST.get("T7C"))
                if tc != 0:

                    b.T7C = tc
                    b.T7K = float(kelvin(b.T7C))
                    li = water_values(b.M7, b.T7C, b.T0K)
                    b.H7 = li[0]
                    b.S7 = li[1]
                    b.E7 = li[2]
                    b.e07 = li[3]
                    b.EX7 = li[4]
                else:
                    pass
            if request.POST.get("P7"):
                p7 = float(request.POST.get("P7"))
                if p7 != 0:

                    b.P7 = p7
                    b.P7kp = float(b.P7) * 100
                    b.H7 = round((0.173 * float(b.P7kp) + 590.73), 4)
                    b.S7 = round((0.000374 * float(b.P7kp) + 1.7671), 4)
                    b.e07 = round((float(b.H7) - float(b.T0K) * float(b.S7)), 4)
                    b.E7 = round((float(b.M7) * float(b.H7) / 1000), 4)

                    b.EX7 = round((float(b.M7) * float(b.e07) / 1000), 4)
                else:
                    pass

            if request.POST.get("T8C"):
                t8c = float(request.POST.get("T8C"))
                if t8c != 0:

                    b.T8C = t8c
                    b.T8K = float(kelvin(b.T8C))
                    li = water_values(b.M8, b.T8C, b.T0K)
                    b.H8 = li[0]
                    b.S8 = li[1]
                    b.E8 = li[2]
                    b.e08 = li[3]
                    b.EX8 = li[4]
                else:
                    pass
            if request.POST.get("P8"):
                p8 = float(request.POST.get("P8"))
                if p8 != 0:
                    b.P8 = p8
                    b.P8kp = float(b.P8) * 100
                    b.H8 = round(0.173 * float(b.P8kp) + 590.73, 4)
                    b.S8 = round(0.000374 * float(b.P8kp) + 1.7671, 4)
                    b.e08 = round(float(b.H8) - float(b.T0K) * float(b.S8), 4)
                    b.E8 = round(float(b.M8) * float(b.H8) / 1000, 4)

                    b.EX8 = round((float(b.M8) * float(b.e08) / 1000), 2)
            b.T9C = float(request.POST["T9C"])
            b.T9K = float(kelvin(b.T9C))
            b.T10C = float(request.POST["T10C"])
            b.T10K = float(kelvin(b.T10C))
            b.P9 = var
            b.P9kp = var * 100
            b.P10 = var2
            b.P10kp = var2 * 100
            if var == 48.0:
                b.H9 = round(2.394 * float(b.T9C) + 2242.7, 4)
                b.S9 = round(0.003416 * float(b.T9C) + 5.29918, 4)
            elif var == 46.0:
                b.H9 = round(2.362 * float(b.T9C) + 2259.1, 4)
                b.S9 = round(0.0034092 * float(b.T9C) + 5.3316, 4)
            elif var == 99.1:
                b.H9 = round(2.64806 * float(b.T9C) + 2052.177, 4)
                b.S9 = round(0.0035439 * float(b.T9C) + 4.833022, 4)
            b.E9 = round(float(b.M9) * float(b.H9) / 1000, 4)
            b.e09 = round(float(b.H9) - float(b.T0K) * b.S9, 4)
            b.EX9 = round(float(b.M9) * float(b.e09) / 1000, 4)

            if var2 == 0.09:
                b.H10 = round(36.26714 * float(b.T10C) + 778.6429, 4)
                b.S10 = round(0.1074 * float(b.T10C) + 2.8041, 4)
            elif var2 == 1.92:
                b.H10 = round(2.007 * float(b.T10C) + 2469.78, 4)
                b.S10 = round(0.0040322 * float(b.T10C) + 6.73441, 4)
            elif var2 == 5.64:
                b.H10 = round(2.12704 * float(b.T10C) + 2427.064, 4)
                b.S10 = round(0.0042748 * float(b.T10C) + 6.146712, 4)
            elif var2 == 16.5:
                b.H10 = round(2.3235 * float(b.T10C) + 2336.995, 4)
                b.S10 = round(0.0042455 * float(b.T10C) + 5.5973, 4)
            b.E10 = round(float(b.M10) * float(b.H10) / 1000, 4)
            b.e010 = round(float(b.H10) - float(b.T0K) * b.S10, 4)
            b.EX10 = round(float(b.M10) * float(b.e010) / 1000, 4)

            b.energy_efficiency = round(((float(b.E8) - float(b.E7)) / (float(b.E9) - float(b.E10)) * 100), 4)
            b.energy_loss = round((float(b.E9) + float(b.E7)) - (float(b.E10) + float(b.E8)), 4)
            b.exergy_efficiency = round(abs(((float(b.EX8) - float(b.EX7)) / (float(b.EX10) - float(b.EX9))) * 100), 4)
            b.exergy_destruction = round(((float(b.EX9) + float(b.EX7)) - (float(b.EX10) + float(b.EX8))), 4)
            b.save()
            return redirect('/compare_result/')


def compare_result(request):
    compare_list= Compare.objects.latest('created_at')
    bfw_list = BFW.objects.latest('created_at')
    en_diff = round(abs(bfw_list.energy_efficiency-compare_list.energy_efficiency),4)
    el_diff = round(abs(bfw_list.energy_loss-compare_list.energy_loss),4)
    ex_diff = round(abs(bfw_list.exergy_efficiency-compare_list.exergy_efficiency),4)
    exd_diff = round(abs(bfw_list.exergy_destruction-compare_list.exergy_destruction),4)
    list1=[
    bfw_list.energy_efficiency,
    bfw_list.energy_loss,
    bfw_list.exergy_efficiency,
    bfw_list.exergy_destruction
    ]
    list2 = [
    compare_list.energy_efficiency,
    compare_list.energy_loss,
    compare_list.exergy_efficiency,
    compare_list.exergy_destruction
    ]
    chart = get_plot(list1,list2)
    pr_en = round(abs(((bfw_list.energy_efficiency - compare_list.energy_efficiency)/compare_list.energy_efficiency)*100),2)
    pr_el = round(abs(((bfw_list.energy_loss - compare_list.energy_loss)/compare_list.energy_loss)*100),2)
    pr_ex = round(abs(((bfw_list.exergy_efficiency - compare_list.exergy_efficiency)/compare_list.exergy_efficiency)*100),2)
    pr_exd = round(abs(((bfw_list.exergy_destruction - compare_list.exergy_destruction)/compare_list.exergy_destruction)*100),2)


    return render(request,"compare_result.html",
    {
    "compare_list":compare_list,
    "bfw_list":bfw_list,
    "en_diff":en_diff,
    "el_diff":el_diff,
    "ex_diff":ex_diff,
    "exd_diff":exd_diff,
    "chart":chart,
    "pr_en":pr_en,
    "pr_el":pr_el,
    "pr_ex":pr_ex,
    "pr_exd":pr_exd

    })
