from django.db import models

from project.models import BaseModel

# Create your models here.


class BFW(BaseModel):
    Name=models.CharField(max_length=100)
    T0C=models.FloatField()
    T0K=models.FloatField()
    M7=models.FloatField()
    T7C=models.FloatField(null=True,blank=True)
    T7K=models.FloatField(null=True,blank=True)
    P7=models.FloatField(null=True,blank=True)
    P7kp=models.FloatField(null=True,blank=True)
    H7=models.FloatField()
    S7=models.FloatField()
    E7=models.FloatField()
    e07=models.FloatField()
    EX7=models.FloatField()
    #bfw_leaving
    M8=models.FloatField()
    T8C=models.FloatField(null=True,blank=True)
    T8K=models.FloatField(null=True,blank=True)
    P8=models.FloatField(null=True,blank=True)
    P8kp=models.FloatField(null=True,blank=True)
    H8=models.FloatField()
    S8=models.FloatField()
    E8=models.FloatField()
    e08=models.FloatField()
    EX8=models.FloatField()
    #high_steam entering
    M9=models.FloatField()
    T9C=models.FloatField()
    T9K=models.FloatField()
    P9=models.FloatField()
    P9kp=models.FloatField(null=True,blank=True)
    H9=models.FloatField()
    S9=models.FloatField()
    E9=models.FloatField()
    e09=models.FloatField()
    EX9=models.FloatField()
    #medium steam leaving
    M10=models.FloatField()
    T10C=models.FloatField()
    T10K=models.FloatField()
    P10=models.FloatField()
    P10kp=models.FloatField(null=True,blank=True)
    H10=models.FloatField()
    S10=models.FloatField()
    E10=models.FloatField()
    e010=models.FloatField()
    EX10=models.FloatField()
    energy_efficiency = models.FloatField()
    energy_loss = models.FloatField()
    exergy_efficiency = models.FloatField()
    exergy_destruction = models.FloatField()
    
    def __str__(self):
        return self.Name


class Compare(BaseModel):
    Name=models.CharField(max_length=100)
    T0C=models.FloatField()
    T0K=models.FloatField()
    M7=models.FloatField()
    T7C = models.FloatField(null=True, blank=True)
    T7K = models.FloatField(null=True, blank=True)
    P7 = models.FloatField(null=True, blank=True)
    P7kp = models.FloatField(null=True, blank=True)
    H7 = models.FloatField()
    S7=models.FloatField()
    E7=models.FloatField()
    e07=models.FloatField()
    EX7=models.FloatField()
    #bfw_leaving
    M8=models.FloatField()
    T8C = models.FloatField(null=True, blank=True)
    T8K = models.FloatField(null=True, blank=True)
    P8 = models.FloatField(null=True, blank=True)
    P8kp = models.FloatField(null=True, blank=True)
    H8=models.FloatField()
    S8=models.FloatField()
    E8=models.FloatField()
    e08=models.FloatField()
    EX8=models.FloatField()
    #high_steam entering
    M9=models.FloatField()
    T9C=models.FloatField()
    T9K=models.FloatField()
    P9=models.FloatField()
    P9kp = models.FloatField(null=True, blank=True)
    H9=models.FloatField()
    S9=models.FloatField()
    E9=models.FloatField()
    e09=models.FloatField()
    EX9=models.FloatField()
    #medium steam leaving
    M10=models.FloatField()
    T10C=models.FloatField()
    T10K=models.FloatField()
    P10=models.FloatField()
    P10kp = models.FloatField(null=True, blank=True)
    H10=models.FloatField()
    S10=models.FloatField()
    E10=models.FloatField()
    e010=models.FloatField()
    EX10=models.FloatField()
    energy_efficiency = models.FloatField()
    energy_loss = models.FloatField()
    exergy_efficiency = models.FloatField()
    exergy_destruction = models.FloatField()
    
    def __str__(self):
        return self.Name



    
    
