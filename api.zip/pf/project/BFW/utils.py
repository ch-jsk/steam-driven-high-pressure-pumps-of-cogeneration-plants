import matplotlib.pyplot as plt
import base64
from io import BytesIO
from .models import BFW,Compare




def get_graph():
    buffer =BytesIO()
    plt.savefig(buffer,format ='png')
    buffer.seek(0)
    image_png = buffer.getvalue()
    graph = base64.b64encode(image_png)
    graph =graph.decode('utf-8')
    buffer.close()
    return graph
    
def get_plot(list1,list2):
    b=BFW.objects.latest("created_at")
    c=Compare.objects.latest("created_at")
    plt.switch_backend('AGG')
    plt.figure(figsize=(10,10))
    
    #plt.title('difference')
    Name = ['en','el','ex','exd']
    fig = plt.figure()
    plt.subplot(2, 2, 1)
    ax=plt.bar(Name[0],list1[0],align='edge',width=0.10,label=b.Name)
    ax2=plt.bar(Name[0],list2[0],align='edge',width=-0.10,label=c.Name)
    plt.title("energy_efficiency")
    
    plt.subplot(2, 2, 2)
    plt.bar(Name[1],list1[1],align='edge',width=0.10)
    plt.bar(Name[1],list2[1],align='edge',width=-0.10)
    plt.title("energy_loss")
    
    plt.subplot(2, 2, 3)
    plt.bar(Name[2],list1[2],align='edge',width=0.10)
    plt.bar(Name[2],list2[2],align='edge',width=-0.10)
    plt.title("exergy_efficiency")
    
    plt.subplot(2, 2, 4)
    plt.bar(Name[3],list1[3],align='edge',width=0.10)
    plt.bar(Name[3],list2[3],align='edge',width=-0.10)
    plt.title("exergy_destruction")
    
    plt.subplots_adjust(
        wspace=0.5,
        hspace=0.5
    )
    labels = [b.Name,c.Name]

    fig.legend([ax,ax2],labels,loc="center")
    
    graph = get_graph()
    return graph